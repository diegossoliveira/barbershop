# 📋 GUIA COMPLETO DE INSTALAÇÃO
### Sistema de Agendamento para Barbearia

---

## O QUE VOCÊ VAI PRECISAR
- Uma conta no **Supabase** (gratuita) → banco de dados
- Uma conta no **Netlify** (você já tem) → hospedagem
- Uma conta no **GitHub** (gratuita) → para conectar com o Netlify

---

## PASSO 1 — CRIAR SUA CONTA NO SUPABASE

1. Acesse **supabase.com**
2. Clique em **"Start your project"** (botão verde)
3. Faça login com sua conta do Google ou crie uma nova conta
4. Clique em **"New Project"**
5. Preencha:
   - **Organization**: deixe como está (cria uma automaticamente)
   - **Name**: escreva `barbearia` (ou o nome que quiser)
   - **Database Password**: crie uma senha forte e ANOTE em algum lugar seguro
   - **Region**: escolha **South America (São Paulo)**
6. Clique em **"Create new project"**
7. Aguarde uns 2 minutinhos enquanto o banco é criado (aparece um carregando)

---

## PASSO 2 — CRIAR AS TABELAS NO SUPABASE

Depois que o projeto carregar, você vai criar as tabelas do banco de dados.

1. No menu da esquerda, clique em **"SQL Editor"** (ícone de código `</>`)
2. Clique em **"New query"** (botão no topo)
3. **Apague tudo** que tiver na caixa de texto
4. **Cole** o código abaixo inteiro:

```sql
-- PROFISSIONAIS
create table profissionais (
  id uuid default gen_random_uuid() primary key,
  nome text not null,
  especialidade text,
  ativo boolean default true,
  criado_em timestamp default now()
);

-- SERVIÇOS
create table servicos (
  id uuid default gen_random_uuid() primary key,
  nome text not null,
  duracao_min integer,
  preco numeric(8,2),
  ativo boolean default true,
  criado_em timestamp default now()
);

-- HORÁRIOS DISPONÍVEIS (por profissional e dia da semana)
-- dia_semana: 0=Dom, 1=Seg, 2=Ter, 3=Qua, 4=Qui, 5=Sex, 6=Sáb
create table horarios_disponiveis (
  id uuid default gen_random_uuid() primary key,
  profissional_id uuid references profissionais(id) on delete cascade,
  dia_semana integer not null check (dia_semana between 0 and 6),
  horario time not null,
  unique(profissional_id, dia_semana, horario)
);

-- AGENDAMENTOS
create table agendamentos (
  id uuid default gen_random_uuid() primary key,
  profissional_id uuid references profissionais(id),
  servico_id uuid references servicos(id),
  data date not null,
  horario time not null,
  cliente_nome text not null,
  cliente_tel text not null,
  status text default 'confirmado' check (status in ('confirmado','cancelado')),
  criado_em timestamp default now()
);

-- LIBERAR ACESSO PÚBLICO (necessário para o site funcionar)
alter table profissionais enable row level security;
alter table servicos enable row level security;
alter table horarios_disponiveis enable row level security;
alter table agendamentos enable row level security;

create policy "Leitura pública" on profissionais for select using (true);
create policy "Leitura pública" on servicos for select using (true);
create policy "Leitura pública" on horarios_disponiveis for select using (true);
create policy "Leitura pública" on agendamentos for select using (true);
create policy "Inserção pública" on agendamentos for insert with check (true);
create policy "Atualização pública" on agendamentos for update using (true);
create policy "Inserção admin" on profissionais for insert with check (true);
create policy "Atualização admin" on profissionais for update using (true);
create policy "Inserção admin" on servicos for insert with check (true);
create policy "Atualização admin" on servicos for update using (true);
create policy "Inserção admin" on horarios_disponiveis for insert with check (true);
create policy "Deleção admin" on horarios_disponiveis for delete using (true);
```

5. Clique no botão verde **"Run"** (ou pressione Ctrl+Enter)
6. Deve aparecer uma mensagem de sucesso em verde. Pronto, tabelas criadas!

---

## PASSO 3 — PEGAR SUAS CHAVES DO SUPABASE

1. No menu da esquerda, clique em **"Project Settings"** (ícone de engrenagem ⚙️)
2. Clique em **"API"**
3. Você vai ver duas informações importantes:
   - **Project URL** → começa com `https://xxxxxx.supabase.co`
   - **anon public** (dentro de "Project API Keys") → uma chave longa

4. Copie essas duas informações e GUARDE — você vai precisar no próximo passo

---

## PASSO 4 — COLOCAR AS CHAVES NO SEU SITE

Abra o arquivo **`js/supabase.js`** e substitua:

```
COLE_SUA_URL_AQUI    →  sua Project URL (ex: https://abcdef.supabase.co)
COLE_SUA_CHAVE_AQUI  →  sua anon public key
```

Ficará assim (exemplo):
```javascript
const SUPABASE_URL = 'https://abcdefghij.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6...';
```

---

## PASSO 5 — COLOCAR NO GITHUB

1. Acesse **github.com** e crie uma conta gratuita (se não tiver)
2. Clique em **"New"** (botão verde com "+" no canto superior esquerdo)
3. Dê um nome ao repositório: ex. `barbearia-agendamento`
4. Deixe como **Public**
5. Clique em **"Create repository"**
6. Na tela seguinte, clique em **"uploading an existing file"**
7. Arraste todos os arquivos da pasta `barbershop` para lá:
   - `index.html`
   - `js/supabase.js`
   - `admin/index.html`
8. Clique em **"Commit changes"** (botão verde lá embaixo)

---

## PASSO 6 — PUBLICAR NO NETLIFY

1. Acesse **netlify.com** e faça login
2. Clique em **"Add new site"** → **"Import an existing project"**
3. Clique em **"Deploy with GitHub"**
4. Autorize o Netlify a acessar seu GitHub (clique em Authorize)
5. Escolha o repositório `barbearia-agendamento`
6. Não mude nada nas configurações
7. Clique em **"Deploy site"**
8. Aguarde 1-2 minutos → seu site vai ficar disponível em um link como:
   `https://nome-aleatorio.netlify.app`

Você pode mudar esse nome em: **Site settings → Change site name**

---

## PASSO 7 — USAR O SISTEMA

### Página do cliente (agendamento):
```
https://seu-site.netlify.app/
```

### Página do administrador (URL SECRETA):
```
https://seu-site.netlify.app/admin/
```
> ⚠️ Não divulgue essa URL! Quem tiver ela terá acesso ao painel de controle.
> Se quiser mais segurança depois, posso adicionar uma senha ao admin.

---

## COMO USAR O PAINEL ADMIN

### Aba "Profissionais"
→ Cadastre os barbeiros/profissionais da barbearia

### Aba "Serviços"
→ Cadastre os serviços oferecidos (corte, barba, etc.) com duração e preço

### Aba "Horários"
→ Para cada profissional, defina quais horários ele atende em cada dia da semana
→ Ex: João → Segunda → 09:00, 09:30, 10:00, 10:30...

### Aba "Agendamentos"
→ Veja todos os agendamentos por data e profissional
→ Cancele agendamentos se necessário

---

## DÚVIDAS FREQUENTES

**O site some os horários que já foram agendados?**
Sim! Automaticamente. Quando alguém agenda um horário, ele desaparece para os próximos.

**Posso usar para várias barbearias?**
Sim! Cada barbearia terá seu próprio projeto no Supabase (gratuito) e seu próprio site no Netlify (gratuito).

**Tem custo?**
Plano gratuito do Supabase suporta até 500MB de banco de dados e 2GB de transferência/mês — mais do que suficiente para uma barbearia.
Netlify gratuito suporta até 100GB de transferência/mês.

**Quero mudar o nome/cores da barbearia no site**
No `index.html`, procure pela linha `<title>` e `<h1>` para mudar o nome.
As cores estão no começo do CSS dentro de `:root { }`.
